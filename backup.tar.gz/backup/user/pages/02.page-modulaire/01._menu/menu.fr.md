---
title: Menu
nompage1: 'Qui sommes nous ?'
urlpage1: page1
nompage2: 'La franchise DAL''ALU'
urlpage2: page2
nompage3: 'Entreprendre avec DAL''ALU'
urlpage3: page3
partpage3:
    -
        text: 'Esprit d''entreprendre'
        url: page3
    -
        text: 'Carte des secteurs'
        url: 'page3#testimonials'
    -
        text: 'Le réseau DAL''ALU'
        url: 'page3#map'
    -
        text: 'Je postule'
        url: 'page3#contact'
nompage4: Documentations
urlpage4: page4
---

