---
title: 'Slider d''images'
listurlslider:
    -
        nom: 'slide 1 p 1 qui sommes nous 1600x900.jpg'
        url: page1.html
    -
        nom: '2la franchise dalalu 1 1600x900 slide 2.jpg'
        url: page2.html
    -
        nom: 'entreprendre avec dalalu slide 3 1600x1000.jpg'
        url: page3.html
---

