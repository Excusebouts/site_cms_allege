---
title: 'Page d''accueil'
content:
    items: '@self.modular'
    order:
        by: folder
        dir: asc
body_classes: modular
onpage_menu: false
---

