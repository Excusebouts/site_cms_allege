---
title: 'Services sans images'
titre_services: 'Nos engagements'
encart_gauche_pictogramme: 'logo fabriqué en france'
encart_gauche_titre: 'Mobile Design'
encart_gauche_texte: "Tous nos produits sont fabriqués en France</br>\r\nLes produits DAL'ALU  sont fabriqués à côté de BORDEAUX en Gironde. </br>\r\nNous mettons à votre service une usine de production de 23 000 m2, </br>\r\nUn production 100% française, du refendage des bobines qui servent à fabriquer sur chantier les produits profilés [gouttières, couvertines et joint debout] aux accessoires de poses qui complètent chaque gamme."
encart_milieu_pictogramme: 'logo dalalu'
encart_milieu_titre: 'Tablet Design'
encart_milieu_texte: "Nos différents services, commercial, communication, technique et logistique sont sur ce même site.\r\nNotre force et la votre,  une réactivité forte et un circuit court de fabrication et distribution."
encart_droite_pictogramme: 'mettre logo garantie 30 ans'
encart_droite_titre: 'Clean Code'
encart_droite_texte: "La garantie qualité de nos produits </br>\r\nFort de son expérience industrielle depuis plusieurs décennies, DAL’ALU s’engage par la traçabilité </br>\r\nde ses produits. DAL’ALU garantit* 30 ans </br>\r\nla qualité de l’aluminium utilisé pour l’ensemble de ses gammes de produits."
encart_droite_texte_cache: 'Lorem ipsum dolor sit amet'
titreservices: test
---

