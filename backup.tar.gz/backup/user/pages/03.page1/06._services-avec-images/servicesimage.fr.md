---
title: 'Services avec images de fond'
titre_services: 'Entreprendre avec DAL''ALU'
encart_haut_gauche_pictogramme: 'picto 1 page 1 qui sommes.jpg'
encart_haut_gauche_titre: 'DAL’ALU, c’est :'
encart_haut_gauche_texte: "> 35 ans d’expérience\r\n> La marque emblématique d’un groupe industriel français\r\n> La créativité d’un leader\r\n> 1 Concept / 1 Marque \r\n> Leader européen de l’Evacuation des eaux pluviales\r\n\tet du profilage en continu\r\n> Bureau d’étude et Recherche &  Développement"
encart_haut_milieu_pictogramme: tablet
encart_haut_milieu_titre: 'Les compétences :'
encart_haut_milieu_texte: "> Des gouttières aux couvertines, du sur-mesure sur vos chantiers\r\n> Profilage en continu sur le chantier / sur mesure\r\n> 1 matériau : l’aluminium laqué\r\n> 1 image de marque forte et reconnue"
encart_haut_droite_pictogramme: code
encart_haut_droite_titre: L’expérience
encart_haut_droite_texte: "> Circuit court approvisionnement\r\n> Unité de production en FRANCE / 23 000 m2 \r\n> + 4000 références \r\n> 1 Réseau porte-parole de la Marque\r\n> Des compétences partagées"
encart_bas_gauche_pictogramme: support
encart_bas_gauche_titre: 'un blabla '
encart_bas_gauche_texte: 'un blablablablablablabla'
encart_bas_milieu_pictogramme: html5
encart_bas_milieu_titre: 'Les +'
encart_bas_milieu_texte: "> 1 accompagnement Pro : Commerce,Gestion,Technique\r\n>  Un fort potentiel de développement\r\n>  Un  modèle d'entreprise évolutif\r\n>  Fabrication française / Garantie 30 ans"
encart_bas_droite_pictogramme: ge
encart_bas_droite_titre: 'Le réseau'
encart_bas_droite_texte: "> 150 entrepreneurs nous font confiance\r\n> + de 450 véhicules-atelier\r\n> Chiffre d’affaire réseau / 50 millions d’€"
encart_droite_pictogramme: ''
encart_bas_pictogramme: ''
---

