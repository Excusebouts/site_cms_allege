---
title: 'Carousel d''images avec textes'
titre: 'L’offre DAL’ALU : + picto ?'
texte: "> Pas de droit d’entrée</br> \r\n> Redevance 4% sur achats</br> \r\n > Un contrat de franchise </br> \r\n> Une offre complète de produits en aluminium pour l’habitat</br> \r\n>  l’évacuation des eaux pluviales et l’enveloppe du bâtiment</br> \r\n> Secteur d’activité : habitat, tertiaire, et industriel, neuf et rénovation</br> \r\n> Achats groupés et accords-cadres</br> \r\n> Accompagnement au quotidien par une équipe de professionnel</br> \r\n\r\nL’offre DAL’ALU € :</br>  \r\n>  Votre investissement total : 45 000 €</br> \r\n>  Investissement 20 000 € : </br> \r\n\t>  Outil de production (Profileuse)</br>\r\n\t>  Formation</br>\r\n\t>  Pack outils de communication  </br>\r\n>  Stock : 15 000 € </br>\r\n>  BFR :  10 000 €</br>\r\n\r\nUn question ?\r\n05 56 67 40 40"
direction: '1'
---

