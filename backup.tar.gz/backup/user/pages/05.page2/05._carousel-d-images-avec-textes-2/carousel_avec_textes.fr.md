---
title: 'Carousel d''images avec textes 2'
titre: 'Les + de la franchise DAL''ALU + picto'
texte: "> 1 accompagnement Pro : Commerce,Gestion,Technique</br> \r\n> Un fort potentiel de développement</br> \r\n> Un  modèle d’entreprise évolutif </br> \r\n> Fabrication française / Garantie 30 ans </br> \r\n> Après 3 ans, C.A. moyen 200 000 €</br> \r\n> Marge brute > à 60 % </br> \r\n> Retour sur investissement : 3 ans</br> \r\n> Une productivité inégalée \tpar le mode de production sur chantier</br>"
direction: '2'
---

