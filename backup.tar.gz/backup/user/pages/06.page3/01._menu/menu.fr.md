---
title: Menu
nompage1: 'Page 1'
urlpage1: page1
nompage2: 'Page 2'
urlpage2: page2
nompage3: 'Page 3'
urlpage3: page3
partpage3:
    -
        text: 'Part 1'
        url: 'page3#'
    -
        text: 'Part 2'
        url: 'page3#testimonials'
    -
        text: 'Part 3'
        url: 'page3#contact'
nompage4: 'Page 4'
urlpage4: page4
---

