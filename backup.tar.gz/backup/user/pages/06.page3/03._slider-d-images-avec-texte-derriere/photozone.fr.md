---
title: 'Slider d''images avec texte derrière'
image_gauche: '1600x1000 accroche des produits pour l''habitat page entreprendre.jpg'
texte_gauche: "Votre projet d'entreprise au sein d'un réseau à taille humaine.</br> \r\nUn métier du bâtiment ou vous pourrez exprimer votre esprit d'entreprendre.  </br> \r\nGestion, développement commerciale, management d'une équipe , vos talents pour commercialiser les produits DAL'ALU.</br> \r\nL'offre : différentes gammes en aluminium pour la finition de l’habitat : </br> \r\névacuations des eaux pluviales, pliages, </br> \r\nsous-faces, volets, bardages, toitures, </br> \r\ncouvertines, boîtes à eau, feuilles à façonner..."
image_droite: '1600x1000 accroche 2 slide 2 entreprendre.jpg'
texte_droite: "Vos compétences, </br>\r\nVous </br>\r\n> avez des talents de chef d’entreprise et de manager</br>\r\n> êtes dynamique</br>\r\n> avez envie d’entreprendre</br>\r\n> avez envie de créer et développer une entreprise stable </br>\r\n> aimez le commerce</br>\r\n> connaissez la gestion</br>\r\n> avez des aptitudes techniques </br>\r\n> avez une b elle capacité à motiver et animer</br>\r\n> avez le sens de l’organisation et du relationnel</br>\r\nDAL’ALU, c’est pour vous ! </br>"
---

