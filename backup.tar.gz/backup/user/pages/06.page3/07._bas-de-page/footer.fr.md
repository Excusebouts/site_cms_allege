---
title: 'Bas de page'
pageaccueil: '2'
list_gauche:
    -
        text: Gouttières
        url: /fr/produits-dal-alu/gouttieres-1/
    -
        text: 'Habillages Aluminium'
        url: /fr/produits-dal-alu/sous-faces/
    -
        text: 'Toitures Aluminium'
        url: /fr/produits-dal-alu/couvertines-et-boites-a-eau/
    -
        text: 'Volets Aluminium'
        url: /fr/produits-dal-alu/volets/
    -
        text: 'Couvertine en continu'
        url: /fr/produits-dal-alu/couverture/
    -
        text: Bardage
        url: /fr/produits-dal-alu/bardages/
    -
        text: Feuilles
        url: /fr/produits-dal-alu/habillages/
list_droite:
    -
        text: 'Plan du site'
        url: /fr/plan-du-site.html
    -
        text: 'Mentions légales'
        url: /fr/mentions-legales.html
nomsociete: 'Société DAL''ALU'
adressesociete: 'Rue des girolles - Z.A. La Prade - 33650 Saint-Médard-d''Eyrans'
telephonesociete: 'Téléphone : +33 (0)5 56 67 40 40 / Fax : +33 (0)5 56 67 40 50'
bouton_texte: 'DALALU près de chez vous'
bouton_url: 'http://www.dalalu.fr/fr/contact.html'
raisonsocialsociete: 'Société DAL''ALU, SAS au capital de 4 200 000 Euros - B 438 705 238 R.C.S BORDEAUX - N° TVA intracommunautaire : FR35 438 705 238'
creditphoto: 'Crédit photos : ©Jean-Marie Colin Photographies / 2016'
copyright: 'Copyright © 1982 - 2015 DAL''ALU. Tous droits réservés.'
conception: 'Conception et réalisation société DAL''ALU.'
---

